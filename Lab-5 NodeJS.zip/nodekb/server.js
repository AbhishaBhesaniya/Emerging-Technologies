const express = require('express');
const bodyparser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 3000


mongoose.connect('mongodb+srv://abhisha:Abhisha@123@cluster0.pf2q6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', {useNewUrlParser: true, useUnifiedTopology: true}, ()=>
    console.log('connected with myFirstDatabase')
);

const kittySchema = new mongoose.Schema({
name: String,
StudentId: String
});
const Kitten = mongoose.model('Kitten', kittySchema);

app.use(bodyparser.json());


app.route('/')
.get(function(req, res){
  res.send('Welcom to home Directory')
})
.put(function (req, res) {
  res.send('Got a PUT request at /')
})
.delete(function (req, res) {
  res.send('Got a DELETE request at /')
})

app.route('/user')
.get(function(req, res){

    const posts = Kitten.find()
    //posts.save()
    .then(posts=>
    {
      res.json(posts);

    });

})
.put(function (req, res) {
  const silence = new Kitten({
  name: req.body.name,
  StudentId: req.body.StudentId
  });
  silence.save()
  .then(data =>
  {
    res.json(data);

  });
})
.delete(function (req, res) {
  //res.send('Got a DELETE request at /user')
  const removePost = Kitten.remove({_id: req.body._id})
  .then(removePost=>
  {
    res.json(removePost);

  });
});

app.listen(3000, function(){
  console.log('Server started on port 3000...')
});
